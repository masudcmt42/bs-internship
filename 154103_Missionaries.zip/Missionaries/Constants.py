class Direction:
	RIGHT = 1
	LEFT = 0


class CONST:
	def __init__(self, MAX_M, MAX_C, CAP_BOAT):
		self.MAX_M = MAX_M
		self.MAX_C = MAX_C
		self.CAP_BOAT = CAP_BOAT

